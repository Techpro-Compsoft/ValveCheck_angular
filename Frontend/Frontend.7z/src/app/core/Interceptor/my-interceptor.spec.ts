import { MyInterceptor } from './my-interceptor';

describe('MyInterceptor', () => {
  it('should create an instance', () => {
    expect(new MyInterceptor()).toBeTruthy();
  });
});
