export const environment = {
  production: true,
  base: 'https://www.techprodevcenter.co.in/valvecheck/api'
};
